#include <stdio.h>
void reverseBits(int a[],int count)
{
    printf(" After: ");
    for(int i=0;i<count;i++)
    {
        printf("%d",a[i]);
    }
}
int main()

{
    int a[10];
    
    int i,j,x,y,count=0;
    printf("Enter the number: ");
    scanf("%d",&x);
    for(i=0;x>0;i++)
    {
        y=x%2;
        x=x/2;
        a[i]=y;
        count=count+1;
    }
    printf("Before: ");
    for(j=i-1;j>=0;j--)
    {
        printf("%d",a[j]);
    }
    reverseBits(a,count);

}
